clear

echo "GARAGA TOOLS"
sleep 2
clear
echo "AUTHOR :MR YUJ1"
sleep 2
clear
echo "BLACK•WOLF CYBER TEAM"
sleep 2
clear
echo "LOADING"
sleep 1
clear
echo "LOADING."
sleep 1
clear
echo "LOADING.."
sleep 1
clear
echo "LOADING..."
sleep 2
clear

toilet "GARAGA"
echo "---------------------------------------------"
echo "|GARAGA TOOLS BY MR.YUJ1 \\\\\\\\\\\\\\\\\\\|"
echo "|////////////////////////NO SYSTEM IS SAFE  |"
echo "|___________________________________________|"
echo "|<<<<<<<<<<<<<<<<SPAMMER>>>>>>>>>>>>>>>>>>>>|"
echo "|___________________________________________|"
echo "|1.GARAGA OFFICIAL SPAMMER                  |"
echo "|-------------------------------------------|"
echo "|2.B4N954N2-ID SPAM CALL                    |"
echo "|-------------------------------------------|"
echo "|3.B4N954N2-ID SPAM CALL V2                 |"
echo "|-------------------------------------------|"
echo "|4.★Indonesia Security Lite★ LITESPAM       |"
echo "|-------------------------------------------|"
echo "|___________________________________________|"

read -p "[+]-" SASA1

if [ $SASA1 == "1" ]
then
    python spamGARAGA.py

elif [ $SASA1 == "2" ]
then
   clear
   toilet "WAIT"
   cd
   pkg install python
   git clone https://github.com/B4N954N2-ID/SpamCall
   cd SpamCall
   python Call.py

elif [ $SASA1 == "3" ]
then
   clear
   toilet "WAIT"
   cd
   pkg install python
   git clone https://github.com/B4N954N2-ID/spam-call
   cd spam-call
   python spam.py

elif [ $SASA1 == "4" ]
then
   pkg update && upgrade
   pkg install git
   pkg install toilet
   pkg install python2
   pkg install figlet
   pkg install php
   clear
   git clone https://github.com/4L13199/LITESPAM
   cd LITESPAM
   sh LITESPAM.sh


fi

